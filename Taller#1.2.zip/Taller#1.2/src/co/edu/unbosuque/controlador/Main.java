package co.edu.unbosuque.controlador;

import co.edu.unbosque.vista.Vista;
import co.edu.unbosuque.modelo.Filecsv;
import co.edu.unbosuque.modelo.ManagerDAO;

public class Main {

	public static void main(String[] args) {
		Controlador c = new Controlador();
	}

}
